GEOG 464 – A3 • Abandoned Mines & Tailings in Québec

What this is:
- final A3 version (no external water layer)
- includes new impact/proximity filter
- ready for VS Code + Live Server
- replace data/mines.geojson with your real mines/tailings dataset from A2/MVP

How to run:
1. open folder in VS Code
2. right-click index.html > Open with Live Server
3. test filters and take 1–2 screenshots
4. zip and upload to Moodle
